const API_BASE = "https://YOUR-BACKEND-URL-HERE"; // Replace with your deployed backend URL, no trailing slash.
    const form = document.getElementById("buildForm");
    const button = document.getElementById("submitBtn");
    const statusBox = document.getElementById("statusBox");
    let pollTimer = null;

    function showStatus(message, isError = false, html = false) {
      statusBox.className = "status show" + (isError ? " error" : "");
      if (html) statusBox.innerHTML = message;
      else statusBox.textContent = message;
    }
    function validPackageName(value) {
      return /^[a-z][a-z0-9]*(\.[a-z][a-z0-9]*)+$/i.test(value);
    }
    async function pollStatus(id) {
      try {
        const response = await fetch(`${API_BASE}/api/status/${encodeURIComponent(id)}`);
        const data = await response.json();
        if (!response.ok) throw new Error(data.error || "Could not read build status.");
        if (data.status === "completed") {
          clearInterval(pollTimer);
          button.disabled = false;
          button.textContent = "🤖 Convert to APK";
          showStatus(`Build complete. <a href="${data.downloadUrl}">Download APK</a>`, false, true);
        } else if (data.status === "failed") {
          clearInterval(pollTimer);
          button.disabled = false;
          button.textContent = "🤖 Convert to APK";
          showStatus(data.message || "Build failed. Check Android SDK/Gradle setup.", true);
        } else {
          showStatus(data.message || "Building APK… This may take several minutes.");
        }
      } catch (error) {
        clearInterval(pollTimer);
        button.disabled = false;
        button.textContent = "🤖 Convert to APK";
        showStatus(error.message, true);
      }
    }
    form.addEventListener("submit", async (event) => {
      event.preventDefault();
      if (API_BASE.includes("YOUR-BACKEND-URL-HERE")) { showStatus("Setup required: replace API_BASE in script.js with your backend HTTPS URL.", true); return; }
      if (pollTimer) clearInterval(pollTimer);
      const websiteUrl = document.getElementById("websiteUrl").value.trim();
      const appName = document.getElementById("appName").value.trim();
      const packageName = document.getElementById("packageName").value.trim();
      try {
        const url = new URL(websiteUrl);
        if (url.protocol !== "https:") throw new Error("Please enter an HTTPS URL (https://…).");
        if (!validPackageName(packageName)) throw new Error("Package name must look like com.example.myapp.");
      } catch (error) {
        showStatus(error.message || "Please enter a valid URL.", true);
        return;
      }
      button.disabled = true;
      button.textContent = "Starting build…";
      showStatus("Submitting build request…");
      try {
        const response = await fetch(`${API_BASE}/api/build`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ websiteUrl, appName, packageName })
        });
        const data = await response.json();
        if (!response.ok) throw new Error(data.error || "Could not start build.");
        showStatus("Build accepted. Preparing Android project…");
        await pollStatus(data.id);
        pollTimer = setInterval(() => pollStatus(data.id), 2500);
      } catch (error) {
        button.disabled = false;
        button.textContent = "🤖 Convert to APK";
        showStatus(error.message, true);
      }
    });
