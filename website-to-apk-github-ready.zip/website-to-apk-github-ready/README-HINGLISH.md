# Website URL se APK — GitHub-only starter

Ye project GitHub Actions se aapke diye hue HTTPS website URL ka Android WebView **debug APK** banata hai. Iske liye alag backend hosting zaroori nahi. Har baar APK banane ke liye GitHub par workflow manually run karein.

## Mobile se setup (Android)

1. GitHub app ya browser mein github.com kholkar login karein.
2. `+` → **New repository** → naam `website-to-apk` → **Create repository**. Public ya Private chun sakte hain; Private behtar hai.
3. Is ZIP ko phone mein **Extract** karein. ZIP file ko seedha upload karne se files extract nahi hoti.
4. Repository mein **Add file → Upload files** karein. Extracted project ke andar ki sab files/folders upload karein, including hidden `.github` folder. Agar mobile upload UI hidden `.github` folder nahi dikhata, GitHub website ka browser Desktop site mode try karein.
5. Upload ke baad repository mein `.github/workflows/build-apk.yml` file zaroor nazar aani chahiye.
6. Repository ke **Actions** tab par jaayein. Agar prompt aaye to **I understand my workflows, go ahead and enable them** select karein.
7. **Build Website APK** workflow kholein → **Run workflow** dabayein.
8. Form mein `website_url` (jaise `https://example.com`), `app_name`, aur `package_name` bharein. Package example: `com.example.mywebsite`. Phir green **Run workflow** button dabayein.
9. Build finish hone tak wait karein. Run par tap karein, neeche **Artifacts** section mein `website-apk` download karein. ZIP extract karein; uske andar `app-debug.apk` milega.
10. APK ko apne Android phone par install karne ke liye download ki hui file kholein. Phone agar permission maange to sirf apne banaye/trusted APK ke liye allow karein.

## Zaroori baatein

- Website URL `https://` se shuru hona chahiye aur website aapki ho ya aapko use package karne ki permission ho.
- Ye APK website ko Android WebView ke andar dikhata hai; website code ko native Android app mein convert nahi karta.
- Ye **debug/test APK** hai, Play Store publish karne ke liye signed release APK nahi.
- GitHub Actions build ko public converter website ke form se automatically connect nahi karta. Is workflow mein har APK GitHub Actions tab se manually banega.
- `frontend/` aur `backend/` original prototype files hain; unka public web form backend abhi automatically deploy/configure nahi hota. Ye workflow unki dependency ke bina APK build karta hai.
